import { create } from "zustand"
import { persist } from "zustand/middleware"
import { apiClient } from "./api-client"

export interface Client {
  id: string
  name: string
  email: string
  phone: string
  company: string
  address: string
  createdAt: string
}

export interface Employee {
  id: string
  name: string
  email: string
  phone: string
  role: string
  categoryId: string
  specializations: string[]
  certifications: string[]
  permissions: string[]
  createdAt: string
}

export interface EmployeeCategory {
  id: string
  name: string
  description: string
  specialtyArea: string
}

export interface Equipment {
  id: string
  name: string
  model: string
  brand: string
  serialNumber: string
  categoryId: string
  location: string
  clientId: string
  purchaseDate?: string
  warrantyExpiry?: string
  status: "operativo" | "mantenimiento" | "fuera_servicio" | "en_reparacion"
  lastMaintenanceDate?: string
  nextMaintenanceDate?: string
  createdAt: string
}

export interface EquipmentCategory {
  id: string
  name: string
  description: string
  maintenanceInterval: number
  requiredSpecialty: string
}

export interface Service {
  id: string
  name: string
  description: string
  categoryId: string
  estimatedTime: number
  price: number
  requiredSpecialties: string[]
  equipmentTypes: string[]
  createdAt: string
}

export interface ServiceCategory {
  id: string
  name: string
  description: string
  serviceType: "preventivo" | "correctivo" | "instalacion" | "diagnostico"
}

export interface Incident {
  id: string
  title: string
  description: string
  categoryId: string
  priority: "baja" | "media" | "alta"
  affectedEquipmentTypes: string[]
  commonCauses: string[]
  createdAt: string
}

export interface IncidentCategory {
  id: string
  name: string
  description: string
  technicalArea: string
}

export interface Ticket {
  id: string
  title: string
  description: string
  clientId: string
  serviceIds: string[]
  equipmentId?: string
  employeeIds: string[]
  incidentIds: string[]
  status: "abierto" | "en_progreso" | "esperando_repuestos" | "cerrado"
  priority: "baja" | "media" | "alta"
  scheduledDate?: string
  completedDate?: string
  estimatedCost?: number
  actualCost?: number
  createdAt: string
  closedAt?: string
}

export interface Message {
  id: string
  ticketId: string
  senderId: string
  senderType: "employee" | "client"
  content: string
  timestamp: string
}

interface TicketingStore {
  // Data
  clients: Client[]
  employees: Employee[]
  employeeCategories: EmployeeCategory[]
  equipment: Equipment[]
  equipmentCategories: EquipmentCategory[]
  services: Service[]
  serviceCategories: ServiceCategory[]
  incidents: Incident[]
  incidentCategories: IncidentCategory[]
  tickets: Ticket[]
  messages: Message[]

  // Loading states
  isLoading: boolean
  error: string | null

  // Initialization
  initializeFromDatabase: () => Promise<void>

  // Client actions
  addClient: (client: Omit<Client, "id" | "createdAt">) => Promise<void>
  updateClient: (id: string, client: Partial<Client>) => Promise<void>
  deleteClient: (id: string) => Promise<void>

  // Employee actions
  addEmployee: (employee: Omit<Employee, "id" | "createdAt">) => Promise<void>
  updateEmployee: (id: string, employee: Partial<Employee>) => Promise<void>
  deleteEmployee: (id: string) => Promise<void>

  // Equipment actions
  addEquipment: (equipment: Omit<Equipment, "id" | "createdAt">) => Promise<void>
  updateEquipment: (id: string, equipment: Partial<Equipment>) => Promise<void>
  deleteEquipment: (id: string) => Promise<void>

  // Service actions
  addService: (service: Omit<Service, "id" | "createdAt">) => Promise<void>
  updateService: (id: string, service: Partial<Service>) => Promise<void>
  deleteService: (id: string) => Promise<void>

  // Ticket actions
  addTicket: (ticket: Omit<Ticket, "id" | "createdAt">) => Promise<void>
  updateTicket: (id: string, ticket: Partial<Ticket>) => Promise<void>
  deleteTicket: (id: string) => Promise<void>
  reopenTicket: (id: string) => Promise<void>

  // Message actions
  addMessage: (message: Omit<Message, "id" | "timestamp">) => Promise<void>
  deleteMessage: (id: string) => Promise<void>

  // Helper functions
  getEquipmentByClient: (clientId: string) => Equipment[]
  getEmployeesBySpecialty: (specialty: string) => Employee[]
  getUpcomingMaintenances: () => Equipment[]

  // Category actions (simplified for now)
  addEmployeeCategory: (category: Omit<EmployeeCategory, "id">) => void
  updateEmployeeCategory: (id: string, category: Partial<EmployeeCategory>) => void
  deleteEmployeeCategory: (id: string) => void
  addEquipmentCategory: (category: Omit<EquipmentCategory, "id">) => void
  updateEquipmentCategory: (id: string, category: Partial<EquipmentCategory>) => void
  deleteEquipmentCategory: (id: string) => void
  addServiceCategory: (category: Omit<ServiceCategory, "id">) => void
  updateServiceCategory: (id: string, category: Partial<ServiceCategory>) => void
  deleteServiceCategory: (id: string) => void
  addIncidentCategory: (category: Omit<IncidentCategory, "id">) => void
  updateIncidentCategory: (id: string, category: Partial<IncidentCategory>) => void
  deleteIncidentCategory: (id: string) => void
}

export const useTicketingStore = create<TicketingStore>()(
  persist(
    (set, get) => ({
      // Initial state
      clients: [],
      employees: [],
      employeeCategories: [],
      equipment: [],
      equipmentCategories: [],
      services: [],
      serviceCategories: [],
      incidents: [],
      incidentCategories: [],
      tickets: [],
      messages: [],
      isLoading: false,
      error: null,

      // Initialize from database
      initializeFromDatabase: async () => {
        set({ isLoading: true, error: null })
        try {
          const [
            clients,
            employees,
            employeeCategories,
            equipment,
            equipmentCategories,
            services,
            serviceCategories,
            tickets,
          ] = await Promise.all([
            apiClient.getClients(),
            apiClient.getEmployees(),
            apiClient.getEmployeeCategories(),
            apiClient.getEquipment(),
            apiClient.getEquipmentCategories(),
            apiClient.getServices(),
            apiClient.getServiceCategories(),
            apiClient.getTickets(),
          ])

          set({
            clients,
            employees,
            employeeCategories,
            equipment,
            equipmentCategories,
            services,
            serviceCategories,
            tickets,
            isLoading: false,
          })
        } catch (error) {
          console.error("Error initializing from database:", error)
          set({ error: error instanceof Error ? error.message : "Unknown error", isLoading: false })
        }
      },

      // Client actions
      addClient: async (clientData) => {
        try {
          const newClient = await apiClient.createClient(clientData)
          set((state) => ({
            clients: [...state.clients, newClient],
          }))
        } catch (error) {
          console.error("Error adding client:", error)
          throw error
        }
      },

      updateClient: async (id, updates) => {
        try {
          const updatedClient = await apiClient.updateClient(id, updates)
          set((state) => ({
            clients: state.clients.map((client) => (client.id === id ? updatedClient : client)),
          }))
        } catch (error) {
          console.error("Error updating client:", error)
          throw error
        }
      },

      deleteClient: async (id) => {
        try {
          await apiClient.deleteClient(id)
          set((state) => ({
            clients: state.clients.filter((client) => client.id !== id),
          }))
        } catch (error) {
          console.error("Error deleting client:", error)
          throw error
        }
      },

      // Employee actions
      addEmployee: async (employeeData) => {
        try {
          const newEmployee = await apiClient.createEmployee(employeeData)
          set((state) => ({
            employees: [...state.employees, newEmployee],
          }))
        } catch (error) {
          console.error("Error adding employee:", error)
          throw error
        }
      },

      updateEmployee: async (id, updates) => {
        try {
          const updatedEmployee = await apiClient.updateEmployee(id, updates)
          set((state) => ({
            employees: state.employees.map((employee) => (employee.id === id ? updatedEmployee : employee)),
          }))
        } catch (error) {
          console.error("Error updating employee:", error)
          throw error
        }
      },

      deleteEmployee: async (id) => {
        try {
          await apiClient.deleteEmployee(id)
          set((state) => ({
            employees: state.employees.filter((employee) => employee.id !== id),
          }))
        } catch (error) {
          console.error("Error deleting employee:", error)
          throw error
        }
      },

      // Equipment actions
      addEquipment: async (equipmentData) => {
        try {
          const newEquipment = await apiClient.createEquipment(equipmentData)
          set((state) => ({
            equipment: [...state.equipment, newEquipment],
          }))
        } catch (error) {
          console.error("Error adding equipment:", error)
          throw error
        }
      },

      updateEquipment: async (id, updates) => {
        try {
          const updatedEquipment = await apiClient.updateEquipment(id, updates)
          set((state) => ({
            equipment: state.equipment.map((equipment) => (equipment.id === id ? updatedEquipment : equipment)),
          }))
        } catch (error) {
          console.error("Error updating equipment:", error)
          throw error
        }
      },

      deleteEquipment: async (id) => {
        try {
          await apiClient.deleteEquipment(id)
          set((state) => ({
            equipment: state.equipment.filter((equipment) => equipment.id !== id),
          }))
        } catch (error) {
          console.error("Error deleting equipment:", error)
          throw error
        }
      },

      // Service actions
      addService: async (serviceData) => {
        try {
          const newService = await apiClient.createService(serviceData)
          set((state) => ({
            services: [...state.services, newService],
          }))
        } catch (error) {
          console.error("Error adding service:", error)
          throw error
        }
      },

      updateService: async (id, updates) => {
        try {
          const updatedService = await apiClient.updateService(id, updates)
          set((state) => ({
            services: state.services.map((service) => (service.id === id ? updatedService : service)),
          }))
        } catch (error) {
          console.error("Error updating service:", error)
          throw error
        }
      },

      deleteService: async (id) => {
        try {
          await apiClient.deleteService(id)
          set((state) => ({
            services: state.services.filter((service) => service.id !== id),
          }))
        } catch (error) {
          console.error("Error deleting service:", error)
          throw error
        }
      },

      // Ticket actions
      addTicket: async (ticketData) => {
        try {
          const newTicket = await apiClient.createTicket(ticketData)
          set((state) => ({
            tickets: [...state.tickets, newTicket],
          }))
        } catch (error) {
          console.error("Error adding ticket:", error)
          throw error
        }
      },

      updateTicket: async (id, updates) => {
        try {
          const updatedTicket = await apiClient.updateTicket(id, updates)
          set((state) => ({
            tickets: state.tickets.map((ticket) => (ticket.id === id ? updatedTicket : ticket)),
          }))
        } catch (error) {
          console.error("Error updating ticket:", error)
          throw error
        }
      },

      deleteTicket: async (id) => {
        try {
          await apiClient.deleteTicket(id)
          set((state) => ({
            tickets: state.tickets.filter((ticket) => ticket.id !== id),
          }))
        } catch (error) {
          console.error("Error deleting ticket:", error)
          throw error
        }
      },

      reopenTicket: async (id) => {
        try {
          await apiClient.updateTicket(id, {
            status: "abierto",
            closedAt: null,
            completedDate: null,
          })
          set((state) => ({
            tickets: state.tickets.map((ticket) =>
              ticket.id === id
                ? { ...ticket, status: "abierto" as const, closedAt: undefined, completedDate: undefined }
                : ticket,
            ),
          }))
        } catch (error) {
          console.error("Error reopening ticket:", error)
          throw error
        }
      },

      // Message actions (simplified for now)
      addMessage: async (messageData) => {
        // This would need to be implemented with API
        console.log("Add message not implemented with database yet")
      },

      deleteMessage: async (id) => {
        // This would need to be implemented with API
        console.log("Delete message not implemented with database yet")
      },

      // Helper functions
      getEquipmentByClient: (clientId: string) => {
        return get().equipment.filter((eq) => eq.clientId === clientId)
      },

      getEmployeesBySpecialty: (specialty: string) => {
        return get().employees.filter((emp) => emp.specializations.includes(specialty))
      },

      getUpcomingMaintenances: () => {
        const today = new Date()
        const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000)
        return get().equipment.filter((eq) => {
          if (!eq.nextMaintenanceDate) return false
          const maintenanceDate = new Date(eq.nextMaintenanceDate)
          return maintenanceDate <= nextWeek
        })
      },

      // Category actions (keeping local for now - these could be moved to API later)
      addEmployeeCategory: (category) => {
        const newCategory = { ...category, id: Math.random().toString(36).substr(2, 9) }
        set((state) => ({
          employeeCategories: [...state.employeeCategories, newCategory],
        }))
      },

      updateEmployeeCategory: (id, updates) => {
        set((state) => ({
          employeeCategories: state.employeeCategories.map((category) =>
            category.id === id ? { ...category, ...updates } : category,
          ),
        }))
      },

      deleteEmployeeCategory: (id) => {
        set((state) => ({
          employeeCategories: state.employeeCategories.filter((category) => category.id !== id),
        }))
      },

      addEquipmentCategory: (category) => {
        const newCategory = { ...category, id: Math.random().toString(36).substr(2, 9) }
        set((state) => ({
          equipmentCategories: [...state.equipmentCategories, newCategory],
        }))
      },

      updateEquipmentCategory: (id, updates) => {
        set((state) => ({
          equipmentCategories: state.equipmentCategories.map((category) =>
            category.id === id ? { ...category, ...updates } : category,
          ),
        }))
      },

      deleteEquipmentCategory: (id) => {
        set((state) => ({
          equipmentCategories: state.equipmentCategories.filter((category) => category.id !== id),
        }))
      },

      addServiceCategory: (category) => {
        const newCategory = { ...category, id: Math.random().toString(36).substr(2, 9) }
        set((state) => ({
          serviceCategories: [...state.serviceCategories, newCategory],
        }))
      },

      updateServiceCategory: (id, updates) => {
        set((state) => ({
          serviceCategories: state.serviceCategories.map((category) =>
            category.id === id ? { ...category, ...updates } : category,
          ),
        }))
      },

      deleteServiceCategory: (id) => {
        set((state) => ({
          serviceCategories: state.serviceCategories.filter((category) => category.id !== id),
        }))
      },

      addIncidentCategory: (category) => {
        const newCategory = { ...category, id: Math.random().toString(36).substr(2, 9) }
        set((state) => ({
          incidentCategories: [...state.incidentCategories, newCategory],
        }))
      },

      updateIncidentCategory: (id, updates) => {
        set((state) => ({
          incidentCategories: state.incidentCategories.map((category) =>
            category.id === id ? { ...category, ...updates } : category,
          ),
        }))
      },

      deleteIncidentCategory: (id) => {
        set((state) => ({
          incidentCategories: state.incidentCategories.filter((category) => category.id !== id),
        }))
      },
    }),
    {
      name: "ticketing-storage",
    },
  ),
)
