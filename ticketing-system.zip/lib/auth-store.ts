import { create } from "zustand"
import { persist } from "zustand/middleware"
import { apiClient } from "./api-client"

export interface User {
  id: string
  username: string
  email: string
  role: "admin" | "supervisor" | "technician"
  permissions: string[]
  employeeId?: string
  isActive: boolean
  lastLogin?: string
  createdAt: string
}

export interface AuthSession {
  user: User | null
  isAuthenticated: boolean
  token?: string
}

interface AuthStore extends AuthSession {
  users: User[]

  // Auth actions
  login: (username: string, password: string) => Promise<boolean>
  logout: () => void
  register: (userData: Omit<User, "id" | "createdAt" | "lastLogin">) => boolean
  updateUser: (id: string, updates: Partial<User>) => void
  deleteUser: (id: string) => void

  // Permission checks
  hasPermission: (permission: string) => boolean
  isAdmin: () => boolean
  isSupervisor: () => boolean

  // User management
  getAllUsers: () => User[]
  getUserById: (id: string) => User | undefined

  // Initialize from database
  initializeFromDatabase: () => Promise<void>
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      token: undefined,
      users: [],

      login: async (username: string, password: string) => {
        try {
          const result = await apiClient.login(username, password)

          if (result.user && result.token) {
            set({
              user: result.user,
              isAuthenticated: true,
              token: result.token,
            })
            return true
          }

          return false
        } catch (error) {
          console.error("Login error:", error)
          return false
        }
      },

      logout: () => {
        apiClient.clearToken()
        set({
          user: null,
          isAuthenticated: false,
          token: undefined,
        })
      },

      register: (userData) => {
        // This would need to be implemented with an API call
        console.log("Register not implemented with database yet")
        return false
      },

      updateUser: (id, updates) => {
        // This would need to be implemented with an API call
        console.log("Update user not implemented with database yet")
      },

      deleteUser: (id) => {
        // This would need to be implemented with an API call
        console.log("Delete user not implemented with database yet")
      },

      hasPermission: (permission: string) => {
        const { user } = get()
        return user?.permissions.includes(permission) || user?.role === "admin" || false
      },

      isAdmin: () => {
        const { user } = get()
        return user?.role === "admin" || false
      },

      isSupervisor: () => {
        const { user } = get()
        return user?.role === "supervisor" || user?.role === "admin" || false
      },

      getAllUsers: () => {
        return get().users
      },

      getUserById: (id: string) => {
        return get().users.find((user) => user.id === id)
      },

      initializeFromDatabase: async () => {
        try {
          // This would fetch users from the database
          // For now, we'll keep the existing users array
          console.log("Initialize from database not fully implemented yet")
        } catch (error) {
          console.error("Error initializing from database:", error)
        }
      },
    }),
    {
      name: "auth-storage",
    },
  ),
)
