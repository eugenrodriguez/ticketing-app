import { prisma } from "./prisma"
import bcrypt from "bcryptjs"

export async function seedDatabase() {
  try {
    // Check if data already exists
    const existingUsers = await prisma.user.count()
    if (existingUsers > 0) {
      console.log("Database already seeded")
      return
    }

    console.log("Seeding database...")

    // Create Employee Categories
    const employeeCategories = await Promise.all([
      prisma.employeeCategory.create({
        data: {
          name: "Técnicos en Refrigeración",
          description: "Especialistas en equipos de frío y climatización",
          specialtyArea: "Refrigeración y Climatización",
        },
      }),
      prisma.employeeCategory.create({
        data: {
          name: "Técnicos en Informática",
          description: "Especialistas en equipos informáticos y redes",
          specialtyArea: "Tecnología de la Información",
        },
      }),
      prisma.employeeCategory.create({
        data: {
          name: "Electricistas",
          description: "Especialistas en sistemas eléctricos e instalaciones",
          specialtyArea: "Sistemas Eléctricos",
        },
      }),
      prisma.employeeCategory.create({
        data: {
          name: "Técnicos en Electrodomésticos",
          description: "Especialistas en reparación de electrodomésticos",
          specialtyArea: "Electrodomésticos",
        },
      }),
    ])

    // Create Equipment Categories
    const equipmentCategories = await Promise.all([
      prisma.equipmentCategory.create({
        data: {
          name: "Equipos de Refrigeración",
          description: "Heladeras, freezers, cámaras frigoríficas y aires acondicionados",
          maintenanceInterval: 90,
          requiredSpecialty: "Refrigeración y Climatización",
        },
      }),
      prisma.equipmentCategory.create({
        data: {
          name: "Equipos Informáticos",
          description: "Computadoras, servidores, impresoras y equipos de red",
          maintenanceInterval: 180,
          requiredSpecialty: "Tecnología de la Información",
        },
      }),
      prisma.equipmentCategory.create({
        data: {
          name: "Electrodomésticos Industriales",
          description: "Lavadoras, secadoras, hornos y equipos de cocina industriales",
          maintenanceInterval: 120,
          requiredSpecialty: "Electrodomésticos",
        },
      }),
      prisma.equipmentCategory.create({
        data: {
          name: "Equipos Eléctricos",
          description: "Motores, tableros eléctricos y sistemas de iluminación",
          maintenanceInterval: 60,
          requiredSpecialty: "Sistemas Eléctricos",
        },
      }),
    ])

    // Create Service Categories
    const serviceCategories = await Promise.all([
      prisma.serviceCategory.create({
        data: {
          name: "Mantenimiento Preventivo",
          description: "Servicios programados para prevenir fallas",
          serviceType: "preventivo",
        },
      }),
      prisma.serviceCategory.create({
        data: {
          name: "Reparaciones",
          description: "Servicios correctivos para solucionar fallas",
          serviceType: "correctivo",
        },
      }),
      prisma.serviceCategory.create({
        data: {
          name: "Instalaciones",
          description: "Servicios de instalación y puesta en marcha",
          serviceType: "instalacion",
        },
      }),
      prisma.serviceCategory.create({
        data: {
          name: "Diagnósticos",
          description: "Servicios de evaluación y diagnóstico técnico",
          serviceType: "diagnostico",
        },
      }),
    ])

    // Create Incident Categories
    const incidentCategories = await Promise.all([
      prisma.incidentCategory.create({
        data: {
          name: "Fallas de Refrigeración",
          description: "Incidentes relacionados con sistemas de frío",
          technicalArea: "Refrigeración",
        },
      }),
      prisma.incidentCategory.create({
        data: {
          name: "Fallas Informáticas",
          description: "Incidentes de hardware y software",
          technicalArea: "Informática",
        },
      }),
      prisma.incidentCategory.create({
        data: {
          name: "Fallas Eléctricas",
          description: "Incidentes del sistema eléctrico",
          technicalArea: "Electricidad",
        },
      }),
      prisma.incidentCategory.create({
        data: {
          name: "Fallas Mecánicas",
          description: "Incidentes de componentes mecánicos",
          technicalArea: "Mecánica",
        },
      }),
    ])

    // Create Clients
    const clients = await Promise.all([
      prisma.client.create({
        data: {
          name: "Juan Pérez",
          email: "juan.perez@email.com",
          phone: "+34 600 123 456",
          company: "Restaurante El Buen Sabor",
          address: "Calle Principal 123, Madrid",
        },
      }),
      prisma.client.create({
        data: {
          name: "María González",
          email: "maria.gonzalez@email.com",
          phone: "+34 600 789 012",
          company: "Oficinas Tech Solutions",
          address: "Avenida Central 456, Barcelona",
        },
      }),
      prisma.client.create({
        data: {
          name: "Carlos Ruiz",
          email: "carlos.ruiz@email.com",
          phone: "+34 600 555 777",
          company: "Lavandería Industrial",
          address: "Polígono Industrial 789, Valencia",
        },
      }),
    ])

    // Create Employees
    const employees = await Promise.all([
      prisma.employee.create({
        data: {
          name: "Carlos Rodríguez",
          email: "carlos@techservice.com",
          phone: "+34 600 111 222",
          role: "Técnico Senior en Refrigeración",
          categoryId: employeeCategories[0].id,
          specializations: JSON.stringify(["Refrigeración comercial", "Aires acondicionados", "Cámaras frigoríficas"]),
          certifications: JSON.stringify(["Certificación en gases refrigerantes", "Técnico en climatización"]),
          permissions: JSON.stringify(["tickets.read", "tickets.write", "equipment.read"]),
        },
      }),
      prisma.employee.create({
        data: {
          name: "Ana López",
          email: "ana@techservice.com",
          phone: "+34 600 333 444",
          role: "Técnica en Sistemas Informáticos",
          categoryId: employeeCategories[1].id,
          specializations: JSON.stringify(["Redes", "Hardware de PC", "Sistemas operativos", "Servidores"]),
          certifications: JSON.stringify(["CompTIA A+", "Cisco CCNA", "Microsoft Certified"]),
          permissions: JSON.stringify(["tickets.read", "tickets.write", "employees.read", "reports.read"]),
        },
      }),
      prisma.employee.create({
        data: {
          name: "Miguel Torres",
          email: "miguel@techservice.com",
          phone: "+34 600 555 666",
          role: "Electricista Industrial",
          categoryId: employeeCategories[2].id,
          specializations: JSON.stringify(["Instalaciones eléctricas", "Motores industriales", "Tableros de control"]),
          certifications: JSON.stringify(["Electricista autorizado", "Seguridad eléctrica industrial"]),
          permissions: JSON.stringify(["tickets.read", "tickets.write", "equipment.read"]),
        },
      }),
    ])

    // Create Users with hashed passwords
    const adminPermissions = [
      "tickets.read",
      "tickets.write",
      "tickets.delete",
      "clients.read",
      "clients.write",
      "clients.delete",
      "employees.read",
      "employees.write",
      "employees.delete",
      "equipment.read",
      "equipment.write",
      "equipment.delete",
      "services.read",
      "services.write",
      "services.delete",
      "incidents.read",
      "incidents.write",
      "incidents.delete",
      "categories.read",
      "categories.write",
      "categories.delete",
      "users.read",
      "users.write",
      "users.delete",
      "reports.read",
      "admin.access",
    ]

    const supervisorPermissions = [
      "tickets.read",
      "tickets.write",
      "clients.read",
      "clients.write",
      "employees.read",
      "equipment.read",
      "equipment.write",
      "services.read",
      "services.write",
      "incidents.read",
      "incidents.write",
      "reports.read",
    ]

    const technicianPermissions = ["tickets.read", "tickets.write", "equipment.read", "services.read", "incidents.read"]

    const users = await Promise.all([
      prisma.user.create({
        data: {
          username: "admin",
          email: "admin@techtickets.com",
          passwordHash: await bcrypt.hash("admin123", 10),
          role: "admin",
          permissions: JSON.stringify(adminPermissions),
          isActive: true,
        },
      }),
      prisma.user.create({
        data: {
          username: "supervisor",
          email: "supervisor@techtickets.com",
          passwordHash: await bcrypt.hash("super123", 10),
          role: "supervisor",
          permissions: JSON.stringify(supervisorPermissions),
          isActive: true,
        },
      }),
      prisma.user.create({
        data: {
          username: "carlos",
          email: "carlos@techtickets.com",
          passwordHash: await bcrypt.hash("carlos123", 10),
          role: "technician",
          employeeId: employees[0].id,
          permissions: JSON.stringify(technicianPermissions),
          isActive: true,
        },
      }),
      prisma.user.create({
        data: {
          username: "ana",
          email: "ana@techtickets.com",
          passwordHash: await bcrypt.hash("ana123", 10),
          role: "supervisor",
          employeeId: employees[1].id,
          permissions: JSON.stringify(supervisorPermissions),
          isActive: true,
        },
      }),
    ])

    // Create Equipment
    const equipment = await Promise.all([
      prisma.equipment.create({
        data: {
          name: "Heladera Industrial Doble Puerta",
          model: "FRI-2000",
          brand: "CoolMaster",
          serialNumber: "CM2000-001",
          categoryId: equipmentCategories[0].id,
          location: "Cocina Principal",
          clientId: clients[0].id,
          purchaseDate: new Date("2023-06-15"),
          warrantyExpiry: new Date("2025-06-15"),
          status: "operativo",
          lastMaintenanceDate: new Date("2024-01-15"),
          nextMaintenanceDate: new Date("2024-04-15"),
        },
      }),
      prisma.equipment.create({
        data: {
          name: "Servidor Dell PowerEdge",
          model: "R740",
          brand: "Dell",
          serialNumber: "DELL-SRV-001",
          categoryId: equipmentCategories[1].id,
          location: "Sala de Servidores",
          clientId: clients[1].id,
          purchaseDate: new Date("2023-08-20"),
          warrantyExpiry: new Date("2026-08-20"),
          status: "operativo",
          lastMaintenanceDate: new Date("2024-01-20"),
          nextMaintenanceDate: new Date("2024-07-20"),
        },
      }),
      prisma.equipment.create({
        data: {
          name: "Lavadora Industrial",
          model: "WM-500",
          brand: "WashPro",
          serialNumber: "WP500-003",
          categoryId: equipmentCategories[2].id,
          location: "Área de Lavado",
          clientId: clients[2].id,
          purchaseDate: new Date("2023-09-10"),
          warrantyExpiry: new Date("2025-09-10"),
          status: "mantenimiento",
          lastMaintenanceDate: new Date("2024-01-25"),
          nextMaintenanceDate: new Date("2024-04-25"),
        },
      }),
    ])

    // Create Services
    const services = await Promise.all([
      prisma.service.create({
        data: {
          name: "Mantenimiento Preventivo de Refrigeración",
          description: "Limpieza de condensadores, verificación de gases, calibración de termostatos",
          categoryId: serviceCategories[0].id,
          estimatedTime: 120,
          price: 150,
          requiredSpecialties: JSON.stringify(["Refrigeración comercial"]),
          equipmentTypes: JSON.stringify(["Equipos de Refrigeración"]),
        },
      }),
      prisma.service.create({
        data: {
          name: "Reparación de Hardware",
          description: "Diagnóstico y reparación de componentes informáticos",
          categoryId: serviceCategories[1].id,
          estimatedTime: 180,
          price: 200,
          requiredSpecialties: JSON.stringify(["Hardware de PC", "Servidores"]),
          equipmentTypes: JSON.stringify(["Equipos Informáticos"]),
        },
      }),
      prisma.service.create({
        data: {
          name: "Instalación Eléctrica",
          description: "Instalación y configuración de sistemas eléctricos",
          categoryId: serviceCategories[2].id,
          estimatedTime: 240,
          price: 300,
          requiredSpecialties: JSON.stringify(["Instalaciones eléctricas"]),
          equipmentTypes: JSON.stringify(["Equipos Eléctricos"]),
        },
      }),
    ])

    // Create Incidents
    const incidents = await Promise.all([
      prisma.incident.create({
        data: {
          title: "Pérdida de Refrigeración",
          description: "El equipo no mantiene la temperatura adecuada",
          categoryId: incidentCategories[0].id,
          priority: "alta",
          affectedEquipmentTypes: JSON.stringify(["Equipos de Refrigeración"]),
          commonCauses: JSON.stringify(["Fuga de gas refrigerante", "Compresor defectuoso", "Termostato descalibrado"]),
        },
      }),
      prisma.incident.create({
        data: {
          title: "Fallo de Sistema",
          description: "El equipo no enciende o se reinicia constantemente",
          categoryId: incidentCategories[1].id,
          priority: "alta",
          affectedEquipmentTypes: JSON.stringify(["Equipos Informáticos"]),
          commonCauses: JSON.stringify([
            "Fuente de alimentación defectuosa",
            "Memoria RAM dañada",
            "Sobrecalentamiento",
          ]),
        },
      }),
      prisma.incident.create({
        data: {
          title: "Sobrecarga Eléctrica",
          description: "Disparo frecuente de protecciones eléctricas",
          categoryId: incidentCategories[2].id,
          priority: "media",
          affectedEquipmentTypes: JSON.stringify(["Equipos Eléctricos", "Electrodomésticos Industriales"]),
          commonCauses: JSON.stringify(["Sobrecarga en el circuito", "Cortocircuito", "Protecciones inadecuadas"]),
        },
      }),
    ])

    console.log("Database seeded successfully!")
  } catch (error) {
    console.error("Error seeding database:", error)
    throw error
  }
}
