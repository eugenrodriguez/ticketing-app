class ApiClient {
  private baseUrl: string
  private token: string | null = null

  constructor(baseUrl = "/api") {
    this.baseUrl = baseUrl
    // Get token from localStorage if available
    if (typeof window !== "undefined") {
      this.token = localStorage.getItem("auth-token")
    }
  }

  setToken(token: string) {
    this.token = token
    if (typeof window !== "undefined") {
      localStorage.setItem("auth-token", token)
    }
  }

  clearToken() {
    this.token = null
    if (typeof window !== "undefined") {
      localStorage.removeItem("auth-token")
    }
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`

    const config: RequestInit = {
      headers: {
        "Content-Type": "application/json",
        ...(this.token && { Authorization: `Bearer ${this.token}` }),
        ...options.headers,
      },
      ...options,
    }

    const response = await fetch(url, config)

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
    }

    return response.json()
  }

  // Auth
  async login(username: string, password: string) {
    const result = await this.request<{ user: any; token: string }>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ username, password }),
    })

    if (result.token) {
      this.setToken(result.token)
    }

    return result
  }

  // Clients
  async getClients() {
    return this.request("/clients")
  }

  async createClient(data: any) {
    return this.request("/clients", {
      method: "POST",
      body: JSON.stringify(data),
    })
  }

  async updateClient(id: string, data: any) {
    return this.request(`/clients/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    })
  }

  async deleteClient(id: string) {
    return this.request(`/clients/${id}`, {
      method: "DELETE",
    })
  }

  // Employees
  async getEmployees() {
    return this.request("/employees")
  }

  async createEmployee(data: any) {
    return this.request("/employees", {
      method: "POST",
      body: JSON.stringify(data),
    })
  }

  async updateEmployee(id: string, data: any) {
    return this.request(`/employees/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    })
  }

  async deleteEmployee(id: string) {
    return this.request(`/employees/${id}`, {
      method: "DELETE",
    })
  }

  // Equipment
  async getEquipment() {
    return this.request("/equipment")
  }

  async createEquipment(data: any) {
    return this.request("/equipment", {
      method: "POST",
      body: JSON.stringify(data),
    })
  }

  async updateEquipment(id: string, data: any) {
    return this.request(`/equipment/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    })
  }

  async deleteEquipment(id: string) {
    return this.request(`/equipment/${id}`, {
      method: "DELETE",
    })
  }

  // Services
  async getServices() {
    return this.request("/services")
  }

  async createService(data: any) {
    return this.request("/services", {
      method: "POST",
      body: JSON.stringify(data),
    })
  }

  async updateService(id: string, data: any) {
    return this.request(`/services/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    })
  }

  async deleteService(id: string) {
    return this.request(`/services/${id}`, {
      method: "DELETE",
    })
  }

  // Categories
  async getEmployeeCategories() {
    return this.request("/categories/employee")
  }

  async getEquipmentCategories() {
    return this.request("/categories/equipment")
  }

  async getServiceCategories() {
    return this.request("/categories/service")
  }

  async getIncidentCategories() {
    return this.request("/categories/incident")
  }

  // Tickets
  async getTickets() {
    return this.request("/tickets")
  }

  async createTicket(data: any) {
    return this.request("/tickets", {
      method: "POST",
      body: JSON.stringify(data),
    })
  }

  async updateTicket(id: string, data: any) {
    return this.request(`/tickets/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    })
  }

  async deleteTicket(id: string) {
    return this.request(`/tickets/${id}`, {
      method: "DELETE",
    })
  }

  // Initialize database
  async initializeDatabase() {
    return this.request("/init", {
      method: "POST",
    })
  }
}

export const apiClient = new ApiClient()
