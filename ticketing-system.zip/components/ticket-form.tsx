"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Clock, DollarSign } from "lucide-react"
import { useTicketingStore, type Ticket } from "@/lib/store"

interface TicketFormProps {
  ticket?: Ticket | null
  onClose: () => void
}

export function TicketForm({ ticket, onClose }: TicketFormProps) {
  const { clients, employees, equipment, services, incidents, addTicket, updateTicket } = useTicketingStore()

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    clientId: "",
    serviceIds: [] as string[],
    equipmentId: "",
    employeeIds: [] as string[],
    incidentIds: [] as string[],
    status: "abierto" as "abierto" | "en_progreso" | "esperando_repuestos" | "cerrado",
    priority: "media" as "baja" | "media" | "alta",
    scheduledDate: "",
    estimatedCost: 0,
  })

  const [filteredEquipment, setFilteredEquipment] = useState(equipment)
  const [recommendedEmployees, setRecommendedEmployees] = useState(employees)

  useEffect(() => {
    if (ticket) {
      setFormData({
        title: ticket.title,
        description: ticket.description,
        clientId: ticket.clientId,
        serviceIds: ticket.serviceIds,
        equipmentId: ticket.equipmentId || "",
        employeeIds: ticket.employeeIds,
        incidentIds: ticket.incidentIds,
        status: ticket.status,
        priority: ticket.priority,
        scheduledDate: ticket.scheduledDate ? ticket.scheduledDate.split("T")[0] : "",
        estimatedCost: ticket.estimatedCost || 0,
      })
    }
  }, [ticket])

  // Filtrar equipos por cliente seleccionado
  useEffect(() => {
    if (formData.clientId) {
      const clientEquipment = equipment.filter((eq) => eq.clientId === formData.clientId)
      setFilteredEquipment(clientEquipment)
    } else {
      setFilteredEquipment(equipment)
    }
  }, [formData.clientId, equipment])

  // Recomendar empleados basado en servicios seleccionados
  useEffect(() => {
    if (formData.serviceIds.length > 0) {
      const selectedServices = services.filter((s) => formData.serviceIds.includes(s.id))
      const requiredSpecialties = selectedServices.flatMap((s) => s.requiredSpecialties)

      const suitableEmployees = employees.filter((emp) =>
        requiredSpecialties.some((specialty) => emp.specializations.includes(specialty)),
      )

      setRecommendedEmployees(suitableEmployees.length > 0 ? suitableEmployees : employees)
    } else {
      setRecommendedEmployees(employees)
    }
  }, [formData.serviceIds, services, employees])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const ticketData = {
      ...formData,
      scheduledDate: formData.scheduledDate ? new Date(formData.scheduledDate).toISOString() : undefined,
    }

    if (ticket) {
      updateTicket(ticket.id, ticketData)
    } else {
      addTicket(ticketData)
    }

    onClose()
  }

  const handleServiceChange = (serviceId: string, checked: boolean | string) => {
    if (checked) {
      setFormData((prev) => ({
        ...prev,
        serviceIds: [...prev.serviceIds, serviceId],
      }))
    } else {
      setFormData((prev) => ({
        ...prev,
        serviceIds: prev.serviceIds.filter((id) => id !== serviceId),
      }))
    }
  }

  const handleEmployeeChange = (employeeId: string, checked: boolean | string) => {
    if (checked) {
      setFormData((prev) => ({
        ...prev,
        employeeIds: [...prev.employeeIds, employeeId],
      }))
    } else {
      setFormData((prev) => ({
        ...prev,
        employeeIds: prev.employeeIds.filter((id) => id !== employeeId),
      }))
    }
  }

  const handleIncidentChange = (incidentId: string, checked: boolean | string) => {
    if (checked) {
      setFormData((prev) => ({
        ...prev,
        incidentIds: [...prev.incidentIds, incidentId],
      }))
    } else {
      setFormData((prev) => ({
        ...prev,
        incidentIds: prev.incidentIds.filter((id) => id !== incidentId),
      }))
    }
  }

  const calculateEstimatedCost = () => {
    const selectedServices = services.filter((s) => formData.serviceIds.includes(s.id))
    return selectedServices.reduce((total, service) => total + service.price, 0)
  }

  const calculateEstimatedTime = () => {
    const selectedServices = services.filter((s) => formData.serviceIds.includes(s.id))
    return selectedServices.reduce((total, service) => total + service.estimatedTime, 0)
  }

  const getEquipmentInfo = (equipmentId: string) => {
    const eq = equipment.find((e) => e.id === equipmentId)
    return eq ? `${eq.name} - ${eq.brand} ${eq.model}` : ""
  }

  const getEmployeeSpecialties = (employeeId: string) => {
    const emp = employees.find((e) => e.id === employeeId)
    return emp ? emp.specializations : []
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="title">Título del Servicio</Label>
          <Input
            id="title"
            value={formData.title}
            onChange={(e) => setFormData((prev) => ({ ...prev, title: e.target.value }))}
            placeholder="Ej: Mantenimiento heladera industrial"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="client">Cliente</Label>
          <Select
            value={formData.clientId}
            onValueChange={(value) => setFormData((prev) => ({ ...prev, clientId: value, equipmentId: "" }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Seleccionar cliente" />
            </SelectTrigger>
            <SelectContent>
              {clients.map((client) => (
                <SelectItem key={client.id} value={client.id}>
                  {client.name} - {client.company}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Descripción del Problema/Servicio</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
          rows={3}
          placeholder="Describe detalladamente el problema o servicio requerido..."
          required
        />
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <div className="space-y-2">
          <Label htmlFor="priority">Prioridad</Label>
          <Select
            value={formData.priority}
            onValueChange={(value: "baja" | "media" | "alta") => setFormData((prev) => ({ ...prev, priority: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Seleccionar prioridad" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="baja">Baja</SelectItem>
              <SelectItem value="media">Media</SelectItem>
              <SelectItem value="alta">Alta</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="status">Estado</Label>
          <Select
            value={formData.status}
            onValueChange={(value: "abierto" | "en_progreso" | "esperando_repuestos" | "cerrado") =>
              setFormData((prev) => ({ ...prev, status: value }))
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Seleccionar estado" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="abierto">Abierto</SelectItem>
              <SelectItem value="en_progreso">En Progreso</SelectItem>
              <SelectItem value="esperando_repuestos">Esperando Repuestos</SelectItem>
              <SelectItem value="cerrado">Cerrado</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="scheduledDate">Fecha Programada</Label>
          <Input
            id="scheduledDate"
            type="date"
            value={formData.scheduledDate}
            onChange={(e) => setFormData((prev) => ({ ...prev, scheduledDate: e.target.value }))}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="estimatedCost">Costo Estimado (€)</Label>
          <Input
            id="estimatedCost"
            type="number"
            min="0"
            step="0.01"
            value={formData.estimatedCost}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, estimatedCost: Number.parseFloat(e.target.value) || 0 }))
            }
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="equipment">Equipo a Intervenir</Label>
        <Select
          value={formData.equipmentId}
          onValueChange={(value) => setFormData((prev) => ({ ...prev, equipmentId: value }))}
        >
          <SelectTrigger>
            <SelectValue placeholder="Seleccionar equipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">Sin equipo específico</SelectItem>
            {filteredEquipment.map((item) => (
              <SelectItem key={item.id} value={item.id}>
                {getEquipmentInfo(item.id)} - {item.location}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {formData.clientId && filteredEquipment.length === 0 && (
          <p className="text-sm text-muted-foreground">Este cliente no tiene equipos registrados</p>
        )}
      </div>

      <div className="space-y-2">
        <Label>Servicios Requeridos</Label>
        <div className="grid gap-2 md:grid-cols-1 border rounded-md p-3 max-h-32 overflow-y-auto">
          {services.map((service) => (
            <div key={service.id} className="flex items-center space-x-2">
              <Checkbox
                id={`service-${service.id}`}
                checked={formData.serviceIds.includes(service.id)}
                onCheckedChange={(checked) => handleServiceChange(service.id, checked)}
              />
              <Label htmlFor={`service-${service.id}`} className="text-sm flex-1">
                <div className="flex justify-between items-center">
                  <span>{service.name}</span>
                  <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                    <span className="flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {service.estimatedTime}min
                    </span>
                    <span className="flex items-center">
                      <DollarSign className="h-3 w-3 mr-1" />€{service.price}
                    </span>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground">{service.description}</div>
              </Label>
            </div>
          ))}
        </div>
        {formData.serviceIds.length > 0 && (
          <div className="flex items-center space-x-4 text-sm bg-blue-50 p-2 rounded">
            <span className="flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              Tiempo total: {calculateEstimatedTime()} min
            </span>
            <span className="flex items-center">
              <DollarSign className="h-4 w-4 mr-1" />
              Costo estimado: €{calculateEstimatedCost()}
            </span>
          </div>
        )}
      </div>

      <div className="space-y-2">
        <Label>Técnicos Asignados</Label>
        <div className="grid gap-2 md:grid-cols-1 border rounded-md p-3 max-h-32 overflow-y-auto">
          {recommendedEmployees.map((employee) => (
            <div key={employee.id} className="flex items-center space-x-2">
              <Checkbox
                id={`employee-${employee.id}`}
                checked={formData.employeeIds.includes(employee.id)}
                onCheckedChange={(checked) => handleEmployeeChange(employee.id, checked)}
              />
              <Label htmlFor={`employee-${employee.id}`} className="text-sm flex-1">
                <div className="flex justify-between items-center">
                  <span>
                    {employee.name} - {employee.role}
                  </span>
                  {formData.serviceIds.length > 0 && (
                    <div className="flex space-x-1">
                      {getEmployeeSpecialties(employee.id).map((specialty) => (
                        <Badge key={specialty} variant="outline" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </Label>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <Label>Incidentes Relacionados</Label>
        <div className="grid gap-2 md:grid-cols-1 border rounded-md p-3 max-h-32 overflow-y-auto">
          {incidents.map((incident) => (
            <div key={incident.id} className="flex items-center space-x-2">
              <Checkbox
                id={`incident-${incident.id}`}
                checked={formData.incidentIds.includes(incident.id)}
                onCheckedChange={(checked) => handleIncidentChange(incident.id, checked)}
              />
              <Label htmlFor={`incident-${incident.id}`} className="text-sm">
                {incident.title} - <span className="text-muted-foreground">{incident.priority}</span>
              </Label>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onClose}>
          Cancelar
        </Button>
        <Button type="submit">{ticket ? "Actualizar" : "Crear"} Ticket</Button>
      </div>
    </form>
  )
}
