"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Database, CheckCircle, AlertCircle } from "lucide-react"
import { apiClient } from "@/lib/api-client"
import { useTicketingStore } from "@/lib/store"

export function DatabaseInitializer() {
  const [isInitializing, setIsInitializing] = useState(false)
  const [isInitialized, setIsInitialized] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const { initializeFromDatabase } = useTicketingStore()

  const handleInitialize = async () => {
    setIsInitializing(true)
    setError(null)

    try {
      // First, seed the database
      await apiClient.initializeDatabase()

      // Then, load data into the store
      await initializeFromDatabase()

      setIsInitialized(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error al inicializar la base de datos")
    } finally {
      setIsInitializing(false)
    }
  }

  const handleLoadData = async () => {
    setIsInitializing(true)
    setError(null)

    try {
      await initializeFromDatabase()
      setIsInitialized(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error al cargar datos")
    } finally {
      setIsInitializing(false)
    }
  }

  if (isInitialized) {
    return (
      <Alert className="mb-6">
        <CheckCircle className="h-4 w-4" />
        <AlertDescription>Base de datos inicializada correctamente. El sistema está listo para usar.</AlertDescription>
      </Alert>
    )
  }

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Database className="h-5 w-5" />
          <span>Inicialización de Base de Datos</span>
        </CardTitle>
        <CardDescription>
          Configura la base de datos con datos de ejemplo para comenzar a usar el sistema.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="flex space-x-2">
          <Button onClick={handleInitialize} disabled={isInitializing} className="flex items-center space-x-2">
            {isInitializing && <Loader2 className="h-4 w-4 animate-spin" />}
            <span>Inicializar Base de Datos</span>
          </Button>

          <Button variant="outline" onClick={handleLoadData} disabled={isInitializing}>
            Solo Cargar Datos
          </Button>
        </div>

        <div className="text-sm text-muted-foreground">
          <p>
            <strong>Inicializar Base de Datos:</strong> Crea las tablas y carga datos de ejemplo (clientes, empleados,
            equipos, etc.)
          </p>
          <p>
            <strong>Solo Cargar Datos:</strong> Carga datos existentes de la base de datos al sistema
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
