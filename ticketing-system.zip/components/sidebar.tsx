"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import {
  Home,
  Ticket,
  Users,
  UserCheck,
  Wrench,
  AlertTriangle,
  Settings,
  FolderTree,
  Monitor,
  Shield,
} from "lucide-react"
import { useAuthStore } from "@/lib/auth-store"
import { UserMenu } from "@/components/auth/user-menu"

const navigation = [
  { name: "Dashboard", href: "/", icon: Home, permission: "tickets.read" },
  { name: "Tickets", href: "/tickets", icon: Ticket, permission: "tickets.read" },
  { name: "Clientes", href: "/clients", icon: Users, permission: "clients.read" },
  { name: "Empleados", href: "/employees", icon: UserCheck, permission: "employees.read" },
  { name: "Equipos", href: "/equipment", icon: Monitor, permission: "equipment.read" },
  { name: "Servicios", href: "/services", icon: Settings, permission: "services.read" },
  { name: "Incidentes", href: "/incidents", icon: AlertTriangle, permission: "incidents.read" },
  { name: "Categorías", href: "/categories", icon: FolderTree, permission: "categories.read" },
]

const adminNavigation = [{ name: "Usuarios", href: "/users", icon: Shield, permission: "users.read", role: "admin" }]

export function Sidebar() {
  const pathname = usePathname()
  const { user, hasPermission, isAdmin } = useAuthStore()

  const filteredNavigation = navigation.filter((item) => hasPermission(item.permission))

  const filteredAdminNavigation = adminNavigation.filter(
    (item) => hasPermission(item.permission) && (!item.role || (item.role === "admin" && isAdmin())),
  )

  return (
    <div className="flex h-full w-64 flex-col border-r bg-background">
      <div className="flex h-16 items-center border-b px-6">
        <div className="flex items-center space-x-2">
          <Wrench className="h-6 w-6 text-primary" />
          <span className="text-lg font-semibold">TechTickets</span>
        </div>
      </div>

      {/* User Info */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center space-x-2">
          <div className="text-sm">
            <p className="font-medium">{user?.username}</p>
            <p className="text-muted-foreground text-xs">{user?.role}</p>
          </div>
        </div>
        <UserMenu />
      </div>

      <ScrollArea className="flex-1 px-3 py-4">
        <nav className="space-y-1">
          {filteredNavigation.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link key={item.name} href={item.href}>
                <Button
                  variant={isActive ? "secondary" : "ghost"}
                  className={cn("w-full justify-start", isActive && "bg-secondary")}
                >
                  <item.icon className="mr-2 h-4 w-4" />
                  {item.name}
                </Button>
              </Link>
            )
          })}

          {filteredAdminNavigation.length > 0 && (
            <>
              <Separator className="my-2" />
              <div className="px-2 py-1">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Administración</p>
              </div>
              {filteredAdminNavigation.map((item) => {
                const isActive = pathname === item.href
                return (
                  <Link key={item.name} href={item.href}>
                    <Button
                      variant={isActive ? "secondary" : "ghost"}
                      className={cn("w-full justify-start", isActive && "bg-secondary")}
                    >
                      <item.icon className="mr-2 h-4 w-4" />
                      {item.name}
                    </Button>
                  </Link>
                )
              })}
            </>
          )}
        </nav>
      </ScrollArea>
    </div>
  )
}
