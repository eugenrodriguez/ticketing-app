"use client"

import type React from "react"
import { useAuthStore } from "@/lib/auth-store"
import { LoginForm } from "./login-form"

interface ProtectedRouteProps {
  children: React.ReactNode
  requiredPermission?: string
  requiredRole?: "admin" | "supervisor" | "technician"
}

export function ProtectedRoute({ children, requiredPermission, requiredRole }: ProtectedRouteProps) {
  const { isAuthenticated, user, hasPermission } = useAuthStore()

  if (!isAuthenticated || !user) {
    return <LoginForm />
  }

  // Verificar rol requerido
  if (requiredRole) {
    if (requiredRole === "admin" && user.role !== "admin") {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-red-600">Acceso Denegado</h2>
            <p className="text-gray-600 mt-2">No tienes permisos de administrador para acceder a esta sección.</p>
          </div>
        </div>
      )
    }

    if (requiredRole === "supervisor" && !["admin", "supervisor"].includes(user.role)) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-red-600">Acceso Denegado</h2>
            <p className="text-gray-600 mt-2">No tienes permisos de supervisor para acceder a esta sección.</p>
          </div>
        </div>
      )
    }
  }

  // Verificar permiso específico
  if (requiredPermission && !hasPermission(requiredPermission)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-red-600">Acceso Denegado</h2>
          <p className="text-gray-600 mt-2">No tienes el permiso necesario para acceder a esta sección.</p>
          <p className="text-sm text-gray-500 mt-1">Permiso requerido: {requiredPermission}</p>
        </div>
      </div>
    )
  }

  return <>{children}</>
}
