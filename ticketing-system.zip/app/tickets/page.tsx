"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Search, Eye, Edit, Trash2, RotateCcw, Calendar, DollarSign } from "lucide-react"
import { useTicketingStore, type Ticket } from "@/lib/store"
import { TicketForm } from "@/components/ticket-form"
import Link from "next/link"

export default function TicketsPage() {
  const { tickets, clients, employees, equipment, updateTicket, deleteTicket, reopenTicket } = useTicketingStore()
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingTicket, setEditingTicket] = useState<Ticket | null>(null)

  const filteredTickets = tickets.filter((ticket) => {
    const matchesSearch =
      ticket.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.id.includes(searchTerm)
    const matchesStatus = statusFilter === "all" || ticket.status === statusFilter
    const matchesPriority = priorityFilter === "all" || ticket.priority === priorityFilter

    return matchesSearch && matchesStatus && matchesPriority
  })

  const getStatusBadge = (status: string) => {
    const variants = {
      abierto: "destructive",
      en_progreso: "secondary",
      esperando_repuestos: "outline",
      cerrado: "default",
    }
    return <Badge variant={variants[status as keyof typeof variants]}>{status.replace("_", " ")}</Badge>
  }

  const getPriorityBadge = (priority: string) => {
    const variants = {
      alta: "destructive",
      media: "secondary",
      baja: "outline",
    }
    return <Badge variant={variants[priority as keyof typeof variants]}>{priority}</Badge>
  }

  const handleEdit = (ticket: Ticket) => {
    setEditingTicket(ticket)
    setIsDialogOpen(true)
  }

  const handleCloseDialog = () => {
    setIsDialogOpen(false)
    setEditingTicket(null)
  }

  const getClientName = (clientId: string) => {
    const client = clients.find((c) => c.id === clientId)
    return client ? `${client.name} (${client.company})` : "Cliente no encontrado"
  }

  const getEmployeeNames = (employeeIds: string[]) => {
    return employeeIds
      .map((id) => {
        const employee = employees.find((e) => e.id === id)
        return employee ? employee.name : "N/A"
      })
      .join(", ")
  }

  const getEquipmentInfo = (equipmentId?: string) => {
    if (!equipmentId) return "Sin equipo específico"
    const eq = equipment.find((e) => e.id === equipmentId)
    return eq ? `${eq.name} (${eq.brand})` : "Equipo no encontrado"
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Gestión de Tickets de Servicio</h1>
          <p className="text-muted-foreground">Administra todos los servicios técnicos del sistema</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingTicket(null)}>
              <Plus className="mr-2 h-4 w-4" />
              Nuevo Ticket
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingTicket ? "Editar Ticket de Servicio" : "Crear Nuevo Ticket de Servicio"}
              </DialogTitle>
              <DialogDescription>
                {editingTicket
                  ? "Modifica la información del ticket de servicio"
                  : "Completa la información para crear un nuevo ticket de servicio técnico"}
              </DialogDescription>
            </DialogHeader>
            <TicketForm ticket={editingTicket} onClose={handleCloseDialog} />
          </DialogContent>
        </Dialog>
      </div>

      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle>Filtros de Búsqueda</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Buscar</label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="ID, título o descripción..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Estado</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos los estados" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los estados</SelectItem>
                  <SelectItem value="abierto">Abierto</SelectItem>
                  <SelectItem value="en_progreso">En Progreso</SelectItem>
                  <SelectItem value="esperando_repuestos">Esperando Repuestos</SelectItem>
                  <SelectItem value="cerrado">Cerrado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Prioridad</label>
              <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Todas las prioridades" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las prioridades</SelectItem>
                  <SelectItem value="alta">Alta</SelectItem>
                  <SelectItem value="media">Media</SelectItem>
                  <SelectItem value="baja">Baja</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Resultados</label>
              <div className="text-sm text-muted-foreground pt-2">{filteredTickets.length} ticket(s) encontrado(s)</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabla de Tickets */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Tickets de Servicio</CardTitle>
          <CardDescription>Todos los servicios técnicos registrados en el sistema</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Servicio</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Equipo</TableHead>
                <TableHead>Técnicos</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Prioridad</TableHead>
                <TableHead>Programado</TableHead>
                <TableHead>Costo</TableHead>
                <TableHead>Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTickets.map((ticket) => (
                <TableRow key={ticket.id}>
                  <TableCell className="font-medium">#{ticket.id}</TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{ticket.title}</div>
                      <div className="text-sm text-muted-foreground truncate max-w-[200px]">{ticket.description}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">{getClientName(ticket.clientId)}</div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">{getEquipmentInfo(ticket.equipmentId)}</div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm truncate max-w-[150px]">{getEmployeeNames(ticket.employeeIds)}</div>
                  </TableCell>
                  <TableCell>{getStatusBadge(ticket.status)}</TableCell>
                  <TableCell>{getPriorityBadge(ticket.priority)}</TableCell>
                  <TableCell>
                    {ticket.scheduledDate ? (
                      <div className="flex items-center text-sm">
                        <Calendar className="h-4 w-4 mr-1" />
                        {new Date(ticket.scheduledDate).toLocaleDateString()}
                      </div>
                    ) : (
                      <span className="text-muted-foreground text-sm">Sin programar</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {ticket.estimatedCost ? (
                      <div className="flex items-center text-sm">
                        <DollarSign className="h-4 w-4 mr-1" />€{ticket.estimatedCost}
                      </div>
                    ) : (
                      <span className="text-muted-foreground text-sm">Sin estimar</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Link href={`/tickets/${ticket.id}`}>
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </Link>
                      <Button variant="outline" size="sm" onClick={() => handleEdit(ticket)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      {ticket.status === "cerrado" && (
                        <Button variant="outline" size="sm" onClick={() => reopenTicket(ticket.id)}>
                          <RotateCcw className="h-4 w-4" />
                        </Button>
                      )}
                      <Button variant="destructive" size="sm" onClick={() => deleteTicket(ticket.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {filteredTickets.length === 0 && (
                <TableRow>
                  <TableCell colSpan={10} className="text-center py-8">
                    No se encontraron tickets que coincidan con los filtros
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
