"use client"

import { useState } from "react"
import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Send, Edit, Save, X, RotateCcw } from "lucide-react"
import { useTicketingStore, type Ticket } from "@/lib/store"
import Link from "next/link"

export default function TicketDetailPage() {
  const params = useParams()
  const ticketId = params.id as string

  const {
    tickets,
    clients,
    employees,
    equipment,
    services,
    incidents,
    messages,
    updateTicket,
    addMessage,
    reopenTicket,
  } = useTicketingStore()

  const ticket = tickets.find((t) => t.id === ticketId)
  const ticketMessages = messages.filter((m) => m.ticketId === ticketId)

  const [isEditing, setIsEditing] = useState(false)
  const [editedTicket, setEditedTicket] = useState<Ticket | null>(ticket || null)
  const [newMessage, setNewMessage] = useState("")

  if (!ticket) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <h2 className="text-2xl font-bold">Ticket no encontrado</h2>
          <p className="text-muted-foreground">El ticket que buscas no existe.</p>
          <Link href="/tickets">
            <Button className="mt-4">Volver a Tickets</Button>
          </Link>
        </div>
      </div>
    )
  }

  const client = clients.find((c) => c.id === ticket.clientId)
  const assignedEmployees = employees.filter((e) => ticket.employeeIds.includes(e.id))
  const assignedServices = services.filter((s) => ticket.serviceIds.includes(s.id))
  const relatedIncidents = incidents.filter((i) => ticket.incidentIds.includes(i.id))
  const assignedEquipment = equipment.find((e) => e.id === ticket.equipmentId)

  const handleSave = () => {
    if (editedTicket) {
      updateTicket(ticketId, editedTicket)
      setIsEditing(false)
    }
  }

  const handleCancel = () => {
    setEditedTicket(ticket)
    setIsEditing(false)
  }

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      addMessage({
        ticketId,
        senderId: "1", // En un sistema real, sería el ID del usuario actual
        senderType: "employee",
        content: newMessage.trim(),
      })
      setNewMessage("")
    }
  }

  const getStatusBadge = (status: string) => {
    const variants = {
      abierto: "destructive",
      en_progreso: "secondary",
      cerrado: "default",
    }
    return <Badge variant={variants[status as keyof typeof variants]}>{status.replace("_", " ")}</Badge>
  }

  const getPriorityBadge = (priority: string) => {
    const variants = {
      alta: "destructive",
      media: "secondary",
      baja: "outline",
    }
    return <Badge variant={variants[priority as keyof typeof variants]}>{priority}</Badge>
  }

  const getSenderName = (senderId: string, senderType: string) => {
    if (senderType === "employee") {
      const employee = employees.find((e) => e.id === senderId)
      return employee ? employee.name : "Empleado desconocido"
    } else {
      const client = clients.find((c) => c.id === senderId)
      return client ? client.name : "Cliente desconocido"
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center space-x-2 mb-2">
            <h1 className="text-3xl font-bold">Ticket #{ticket.id}</h1>
            {getStatusBadge(isEditing && editedTicket ? editedTicket.status : ticket.status)}
            {getPriorityBadge(isEditing && editedTicket ? editedTicket.priority : ticket.priority)}
          </div>
          <p className="text-muted-foreground">
            Creado el {new Date(ticket.createdAt).toLocaleString()}
            {ticket.closedAt && <> • Cerrado el {new Date(ticket.closedAt).toLocaleString()}</>}
          </p>
        </div>
        <div className="flex space-x-2">
          {ticket.status === "cerrado" && (
            <Button variant="outline" onClick={() => reopenTicket(ticketId)}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Reabrir
            </Button>
          )}
          {isEditing ? (
            <>
              <Button variant="outline" onClick={handleCancel}>
                <X className="mr-2 h-4 w-4" />
                Cancelar
              </Button>
              <Button onClick={handleSave}>
                <Save className="mr-2 h-4 w-4" />
                Guardar
              </Button>
            </>
          ) : (
            <Button onClick={() => setIsEditing(true)}>
              <Edit className="mr-2 h-4 w-4" />
              Editar
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Información Principal */}
        <div className="lg:col-span-2 space-y-6">
          {/* Detalles del Ticket */}
          <Card>
            <CardHeader>
              <CardTitle>Detalles del Ticket</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Título</Label>
                {isEditing && editedTicket ? (
                  <Input
                    value={editedTicket.title}
                    onChange={(e) => setEditedTicket((prev) => (prev ? { ...prev, title: e.target.value } : null))}
                  />
                ) : (
                  <p className="text-sm">{ticket.title}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Descripción</Label>
                {isEditing && editedTicket ? (
                  <Textarea
                    value={editedTicket.description}
                    onChange={(e) =>
                      setEditedTicket((prev) => (prev ? { ...prev, description: e.target.value } : null))
                    }
                    rows={4}
                  />
                ) : (
                  <p className="text-sm whitespace-pre-wrap">{ticket.description}</p>
                )}
              </div>

              {isEditing && editedTicket && (
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Estado</Label>
                    <Select
                      value={editedTicket.status}
                      onValueChange={(value: "abierto" | "en_progreso" | "cerrado") =>
                        setEditedTicket((prev) => (prev ? { ...prev, status: value } : null))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="abierto">Abierto</SelectItem>
                        <SelectItem value="en_progreso">En Progreso</SelectItem>
                        <SelectItem value="cerrado">Cerrado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Prioridad</Label>
                    <Select
                      value={editedTicket.priority}
                      onValueChange={(value: "baja" | "media" | "alta") =>
                        setEditedTicket((prev) => (prev ? { ...prev, priority: value } : null))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="baja">Baja</SelectItem>
                        <SelectItem value="media">Media</SelectItem>
                        <SelectItem value="alta">Alta</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Mensajes */}
          <Card>
            <CardHeader>
              <CardTitle>Conversación</CardTitle>
              <CardDescription>Historial de mensajes del ticket</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {ticketMessages.map((message) => (
                  <div key={message.id} className="flex space-x-3">
                    <Avatar>
                      <AvatarFallback>{getSenderName(message.senderId, message.senderType).charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center space-x-2">
                        <p className="text-sm font-medium">{getSenderName(message.senderId, message.senderType)}</p>
                        <Badge variant="outline" className="text-xs">
                          {message.senderType === "employee" ? "Empleado" : "Cliente"}
                        </Badge>
                        <p className="text-xs text-muted-foreground">{new Date(message.timestamp).toLocaleString()}</p>
                      </div>
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    </div>
                  </div>
                ))}
                {ticketMessages.length === 0 && (
                  <p className="text-center text-muted-foreground py-8">No hay mensajes en este ticket</p>
                )}
              </div>

              <Separator className="my-4" />

              <div className="space-y-2">
                <Label>Nuevo Mensaje</Label>
                <div className="flex space-x-2">
                  <Textarea
                    placeholder="Escribe tu mensaje aquí..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    rows={3}
                    className="flex-1"
                  />
                  <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Panel Lateral */}
        <div className="space-y-6">
          {/* Información del Cliente */}
          <Card>
            <CardHeader>
              <CardTitle>Cliente</CardTitle>
            </CardHeader>
            <CardContent>
              {client ? (
                <div className="space-y-2">
                  <p className="font-medium">{client.name}</p>
                  <p className="text-sm text-muted-foreground">{client.company}</p>
                  <p className="text-sm">{client.email}</p>
                  <p className="text-sm">{client.phone}</p>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">Cliente no encontrado</p>
              )}
            </CardContent>
          </Card>

          {/* Empleados Asignados */}
          <Card>
            <CardHeader>
              <CardTitle>Empleados Asignados</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {assignedEmployees.map((employee) => (
                  <div key={employee.id} className="flex items-center space-x-2">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="text-xs">{employee.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">{employee.name}</p>
                      <p className="text-xs text-muted-foreground">{employee.role}</p>
                    </div>
                  </div>
                ))}
                {assignedEmployees.length === 0 && (
                  <p className="text-sm text-muted-foreground">Sin empleados asignados</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Servicios */}
          <Card>
            <CardHeader>
              <CardTitle>Servicios</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {assignedServices.map((service) => (
                  <div key={service.id} className="p-2 border rounded">
                    <p className="text-sm font-medium">{service.name}</p>
                    <p className="text-xs text-muted-foreground">{service.description}</p>
                    <p className="text-xs text-muted-foreground">Tiempo estimado: {service.estimatedTime} min</p>
                  </div>
                ))}
                {assignedServices.length === 0 && (
                  <p className="text-sm text-muted-foreground">Sin servicios asignados</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Equipo */}
          {assignedEquipment && (
            <Card>
              <CardHeader>
                <CardTitle>Equipo</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="font-medium">{assignedEquipment.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {assignedEquipment.brand} {assignedEquipment.model}
                  </p>
                  <p className="text-sm text-muted-foreground">S/N: {assignedEquipment.serialNumber}</p>
                  <p className="text-sm text-muted-foreground">Ubicación: {assignedEquipment.location}</p>
                  <Badge variant="outline">{assignedEquipment.status}</Badge>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Incidentes Relacionados */}
          {relatedIncidents.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Incidentes Relacionados</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {relatedIncidents.map((incident) => (
                    <div key={incident.id} className="p-2 border rounded">
                      <p className="text-sm font-medium">{incident.title}</p>
                      <p className="text-xs text-muted-foreground">{incident.description}</p>
                      <Badge variant="outline" className="text-xs">
                        {incident.priority}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
