import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function GET() {
  try {
    const employees = await prisma.employee.findMany({
      include: {
        category: true,
        user: true,
      },
      orderBy: { createdAt: "desc" },
    })

    // Transform data to match frontend structure
    const transformedEmployees = employees.map((employee) => ({
      ...employee,
      specializations: JSON.parse(employee.specializations || "[]"),
      certifications: JSON.parse(employee.certifications || "[]"),
      permissions: JSON.parse(employee.permissions || "[]"),
    }))

    return NextResponse.json(transformedEmployees)
  } catch (error) {
    console.error("Error fetching employees:", error)
    return NextResponse.json({ error: "Failed to fetch employees" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    const employee = await prisma.employee.create({
      data: {
        name: data.name,
        email: data.email,
        phone: data.phone,
        role: data.role,
        categoryId: data.categoryId,
        specializations: JSON.stringify(data.specializations || []),
        certifications: JSON.stringify(data.certifications || []),
        permissions: JSON.stringify(data.permissions || []),
      },
    })

    return NextResponse.json(employee, { status: 201 })
  } catch (error) {
    console.error("Error creating employee:", error)
    return NextResponse.json({ error: "Failed to create employee" }, { status: 500 })
  }
}
