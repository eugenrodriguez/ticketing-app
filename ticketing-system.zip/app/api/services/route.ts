import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function GET() {
  try {
    const services = await prisma.service.findMany({
      include: {
        category: true,
      },
      orderBy: { createdAt: "desc" },
    })

    // Transform data to match frontend structure
    const transformedServices = services.map((service) => ({
      ...service,
      requiredSpecialties: JSON.parse(service.requiredSpecialties || "[]"),
      equipmentTypes: JSON.parse(service.equipmentTypes || "[]"),
    }))

    return NextResponse.json(transformedServices)
  } catch (error) {
    console.error("Error fetching services:", error)
    return NextResponse.json({ error: "Failed to fetch services" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    const service = await prisma.service.create({
      data: {
        name: data.name,
        description: data.description,
        categoryId: data.categoryId,
        estimatedTime: data.estimatedTime,
        price: data.price,
        requiredSpecialties: JSON.stringify(data.requiredSpecialties || []),
        equipmentTypes: JSON.stringify(data.equipmentTypes || []),
      },
    })

    return NextResponse.json(service, { status: 201 })
  } catch (error) {
    console.error("Error creating service:", error)
    return NextResponse.json({ error: "Failed to create service" }, { status: 500 })
  }
}
