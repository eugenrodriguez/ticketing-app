import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function GET() {
  try {
    const tickets = await prisma.ticket.findMany({
      include: {
        client: true,
        equipment: true,
        ticketEmployees: {
          include: {
            employee: true,
          },
        },
        ticketServices: {
          include: {
            service: true,
          },
        },
        ticketIncidents: {
          include: {
            incident: true,
          },
        },
        messages: {
          include: {
            sender: true,
          },
          orderBy: {
            timestamp: "asc",
          },
        },
      },
      orderBy: { createdAt: "desc" },
    })

    // Transform the data to match the frontend structure
    const transformedTickets = tickets.map((ticket) => ({
      ...ticket,
      employeeIds: ticket.ticketEmployees.map((te) => te.employeeId),
      serviceIds: ticket.ticketServices.map((ts) => ts.serviceId),
      incidentIds: ticket.ticketIncidents.map((ti) => ti.incidentId),
    }))

    return NextResponse.json(transformedTickets)
  } catch (error) {
    console.error("Error fetching tickets:", error)
    return NextResponse.json({ error: "Failed to fetch tickets" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    const ticket = await prisma.ticket.create({
      data: {
        title: data.title,
        description: data.description,
        clientId: data.clientId,
        equipmentId: data.equipmentId || null,
        status: data.status,
        priority: data.priority,
        scheduledDate: data.scheduledDate ? new Date(data.scheduledDate) : null,
        estimatedCost: data.estimatedCost || null,
      },
    })

    // Create employee relations
    if (data.employeeIds && data.employeeIds.length > 0) {
      await prisma.ticketEmployee.createMany({
        data: data.employeeIds.map((employeeId: string) => ({
          ticketId: ticket.id,
          employeeId,
        })),
      })
    }

    // Create service relations
    if (data.serviceIds && data.serviceIds.length > 0) {
      await prisma.ticketService.createMany({
        data: data.serviceIds.map((serviceId: string) => ({
          ticketId: ticket.id,
          serviceId,
        })),
      })
    }

    // Create incident relations
    if (data.incidentIds && data.incidentIds.length > 0) {
      await prisma.ticketIncident.createMany({
        data: data.incidentIds.map((incidentId: string) => ({
          ticketId: ticket.id,
          incidentId,
        })),
      })
    }

    return NextResponse.json(ticket, { status: 201 })
  } catch (error) {
    console.error("Error creating ticket:", error)
    return NextResponse.json({ error: "Failed to create ticket" }, { status: 500 })
  }
}
