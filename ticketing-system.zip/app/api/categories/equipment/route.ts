import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function GET() {
  try {
    const categories = await prisma.equipmentCategory.findMany({
      orderBy: { name: "asc" },
    })

    return NextResponse.json(categories)
  } catch (error) {
    console.error("Error fetching equipment categories:", error)
    return NextResponse.json({ error: "Failed to fetch equipment categories" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    const category = await prisma.equipmentCategory.create({
      data: {
        name: data.name,
        description: data.description,
        maintenanceInterval: data.maintenanceInterval,
        requiredSpecialty: data.requiredSpecialty,
      },
    })

    return NextResponse.json(category, { status: 201 })
  } catch (error) {
    console.error("Error creating equipment category:", error)
    return NextResponse.json({ error: "Failed to create equipment category" }, { status: 500 })
  }
}
