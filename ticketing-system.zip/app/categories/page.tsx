"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Plus, Search, Edit, Trash2, Users, Monitor, Settings, AlertTriangle } from "lucide-react"
import { useTicketingStore } from "@/lib/store"

export default function CategoriesPage() {
  const {
    employeeCategories,
    equipmentCategories,
    serviceCategories,
    incidentCategories,
    employees,
    equipment,
    services,
    incidents,
    addEmployeeCategory,
    updateEmployeeCategory,
    deleteEmployeeCategory,
    addEquipmentCategory,
    updateEquipmentCategory,
    deleteEquipmentCategory,
    addServiceCategory,
    updateServiceCategory,
    deleteServiceCategory,
    addIncidentCategory,
    updateIncidentCategory,
    deleteIncidentCategory,
  } = useTicketingStore()

  const [searchTerm, setSearchTerm] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingCategory, setEditingCategory] = useState(null)
  const [categoryType, setCategoryType] = useState("employee")
  const [formData, setFormData] = useState({
    name: "",
    description: "",
  })

  const getFilteredCategories = (categories) => {
    return categories.filter(
      (category) =>
        category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        category.description.toLowerCase().includes(searchTerm.toLowerCase()),
    )
  }

  const getCategoryUsageCount = (categoryId, type) => {
    switch (type) {
      case "employee":
        return employees.filter((e) => e.categoryId === categoryId).length
      case "equipment":
        return equipment.filter((e) => e.categoryId === categoryId).length
      case "service":
        return services.filter((s) => s.categoryId === categoryId).length
      case "incident":
        return incidents.filter((i) => i.categoryId === categoryId).length
      default:
        return 0
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    const actions = {
      employee: editingCategory
        ? () => updateEmployeeCategory(editingCategory.id, formData)
        : () => addEmployeeCategory(formData),
      equipment: editingCategory
        ? () => updateEquipmentCategory(editingCategory.id, formData)
        : () => addEquipmentCategory(formData),
      service: editingCategory
        ? () => updateServiceCategory(editingCategory.id, formData)
        : () => addServiceCategory(formData),
      incident: editingCategory
        ? () => updateIncidentCategory(editingCategory.id, formData)
        : () => addIncidentCategory(formData),
    }

    actions[categoryType]()
    handleCloseDialog()
  }

  const handleEdit = (category, type) => {
    setEditingCategory(category)
    setCategoryType(type)
    setFormData({
      name: category.name,
      description: category.description,
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (categoryId, type) => {
    const actions = {
      employee: () => deleteEmployeeCategory(categoryId),
      equipment: () => deleteEquipmentCategory(categoryId),
      service: () => deleteServiceCategory(categoryId),
      incident: () => deleteIncidentCategory(categoryId),
    }

    actions[type]()
  }

  const handleCloseDialog = () => {
    setIsDialogOpen(false)
    setEditingCategory(null)
    setFormData({
      name: "",
      description: "",
    })
  }

  const handleNewCategory = (type) => {
    setCategoryType(type)
    setEditingCategory(null)
    setIsDialogOpen(true)
  }

  const CategoryTable = ({ categories, type, icon: Icon, title }) => (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Icon className="h-5 w-5" />
            <CardTitle>{title}</CardTitle>
          </div>
          <Button onClick={() => handleNewCategory(type)}>
            <Plus className="mr-2 h-4 w-4" />
            Nueva Categoría
          </Button>
        </div>
        <CardDescription>Gestiona las categorías de {title.toLowerCase()}</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nombre</TableHead>
              <TableHead>Descripción</TableHead>
              <TableHead>Elementos</TableHead>
              <TableHead>Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {getFilteredCategories(categories).map((category) => (
              <TableRow key={category.id}>
                <TableCell className="font-medium">{category.name}</TableCell>
                <TableCell>
                  <div className="max-w-[300px] truncate text-sm text-muted-foreground">{category.description}</div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{getCategoryUsageCount(category.id, type)} elementos</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm" onClick={() => handleEdit(category, type)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => handleDelete(category.id, type)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {getFilteredCategories(categories).length === 0 && (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8">
                  No se encontraron categorías que coincidan con la búsqueda
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )

  const getCategoryTypeTitle = (type) => {
    const titles = {
      employee: "Categoría de Empleado",
      equipment: "Categoría de Equipo",
      service: "Categoría de Servicio",
      incident: "Categoría de Incidente",
    }
    return titles[type]
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Gestión de Categorías</h1>
          <p className="text-muted-foreground">Administra todas las categorías del sistema</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingCategory ? "Editar" : "Crear Nueva"} {getCategoryTypeTitle(categoryType)}
              </DialogTitle>
              <DialogDescription>
                {editingCategory
                  ? "Modifica la información de la categoría"
                  : `Completa la información para crear una nueva ${getCategoryTypeTitle(categoryType).toLowerCase()}`}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                  rows={3}
                  required
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={handleCloseDialog}>
                  Cancelar
                </Button>
                <Button type="submit">{editingCategory ? "Actualizar" : "Crear"} Categoría</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Búsqueda Global */}
      <Card>
        <CardHeader>
          <CardTitle>Buscar en Todas las Categorías</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por nombre o descripción..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>
        </CardContent>
      </Card>

      {/* Tabs para diferentes tipos de categorías */}
      <Tabs defaultValue="employees" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="employees" className="flex items-center space-x-2">
            <Users className="h-4 w-4" />
            <span>Empleados</span>
          </TabsTrigger>
          <TabsTrigger value="equipment" className="flex items-center space-x-2">
            <Monitor className="h-4 w-4" />
            <span>Equipos</span>
          </TabsTrigger>
          <TabsTrigger value="services" className="flex items-center space-x-2">
            <Settings className="h-4 w-4" />
            <span>Servicios</span>
          </TabsTrigger>
          <TabsTrigger value="incidents" className="flex items-center space-x-2">
            <AlertTriangle className="h-4 w-4" />
            <span>Incidentes</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="employees">
          <CategoryTable categories={employeeCategories} type="employee" icon={Users} title="Categorías de Empleados" />
        </TabsContent>

        <TabsContent value="equipment">
          <CategoryTable
            categories={equipmentCategories}
            type="equipment"
            icon={Monitor}
            title="Categorías de Equipos"
          />
        </TabsContent>

        <TabsContent value="services">
          <CategoryTable
            categories={serviceCategories}
            type="service"
            icon={Settings}
            title="Categorías de Servicios"
          />
        </TabsContent>

        <TabsContent value="incidents">
          <CategoryTable
            categories={incidentCategories}
            type="incident"
            icon={AlertTriangle}
            title="Categorías de Incidentes"
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}
