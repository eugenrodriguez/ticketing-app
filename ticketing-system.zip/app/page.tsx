"use client"

import { useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CalendarDays, Users, AlertCircle, CheckCircle, Wrench, Clock, DollarSign } from "lucide-react"
import { useTicketingStore } from "@/lib/store"
import { DatabaseInitializer } from "@/components/database-initializer"

export default function Dashboard() {
  const {
    tickets,
    clients,
    employees,
    equipment: allEquipment,
    getUpcomingMaintenances,
    initializeFromDatabase,
  } = useTicketingStore()

  useEffect(() => {
    // Try to load data from database on component mount
    initializeFromDatabase().catch(console.error)
  }, [initializeFromDatabase])

  const openTickets = tickets.filter((t) => t.status !== "cerrado").length
  const closedTickets = tickets.filter((t) => t.status === "cerrado").length
  const highPriorityTickets = tickets.filter((t) => t.priority === "alta" && t.status !== "cerrado").length
  const todayTickets = tickets.filter((t) => {
    const today = new Date().toISOString().split("T")[0]
    return t.createdAt.split("T")[0] === today
  }).length

  const upcomingMaintenances = getUpcomingMaintenances()
  const equipmentInMaintenance = allEquipment.filter(
    (e) => e.status === "mantenimiento" || e.status === "en_reparacion",
  ).length

  const recentTickets = tickets.slice(-5).reverse()

  const totalRevenue = tickets
    .filter((t) => t.status === "cerrado" && t.actualCost)
    .reduce((sum, t) => sum + (t.actualCost || 0), 0)

  const pendingRevenue = tickets
    .filter((t) => t.status !== "cerrado" && t.estimatedCost)
    .reduce((sum, t) => sum + (t.estimatedCost || 0), 0)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard - Servicios Técnicos</h1>
        <p className="text-muted-foreground">Resumen general del sistema de servicios técnicos especializados</p>
      </div>

      {/* Database Initializer */}
      <DatabaseInitializer />

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Servicios Activos</CardTitle>
            <Wrench className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{openTickets}</div>
            <p className="text-xs text-muted-foreground">{highPriorityTickets} de alta prioridad</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Servicios Completados</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{closedTickets}</div>
            <p className="text-xs text-muted-foreground">Total finalizados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Equipos en Servicio</CardTitle>
            <AlertCircle className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{equipmentInMaintenance}</div>
            <p className="text-xs text-muted-foreground">En mantenimiento/reparación</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Clientes Activos</CardTitle>
            <Users className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{clients.length}</div>
            <p className="text-xs text-muted-foreground">Total registrados</p>
          </CardContent>
        </Card>
      </div>

      {/* Revenue and Maintenance Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <DollarSign className="h-5 w-5 mr-2" />
              Ingresos
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm">Facturado:</span>
              <span className="font-medium">€{totalRevenue.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">Pendiente:</span>
              <span className="font-medium">€{pendingRevenue.toFixed(2)}</span>
            </div>
            <div className="flex justify-between border-t pt-2">
              <span className="text-sm font-medium">Total Proyectado:</span>
              <span className="font-bold">€{(totalRevenue + pendingRevenue).toFixed(2)}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Clock className="h-5 w-5 mr-2" />
              Mantenimientos Próximos
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm">Esta semana:</span>
              <Badge variant="destructive">{upcomingMaintenances.length}</Badge>
            </div>
            <div className="space-y-1">
              {upcomingMaintenances.slice(0, 3).map((equipment) => (
                <div key={equipment.id} className="text-xs text-muted-foreground">
                  {equipment.name} - {new Date(equipment.nextMaintenanceDate!).toLocaleDateString()}
                </div>
              ))}
              {upcomingMaintenances.length > 3 && (
                <div className="text-xs text-muted-foreground">+{upcomingMaintenances.length - 3} más...</div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Técnicos Especializados</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm">Total:</span>
              <span className="font-medium">{employees.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">Refrigeración:</span>
              <span className="font-medium">
                {employees.filter((e) => e.specializations.some((s) => s.includes("Refrigeración"))).length}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">Informática:</span>
              <span className="font-medium">
                {
                  employees.filter((e) => e.specializations.some((s) => s.includes("Hardware") || s.includes("Redes")))
                    .length
                }
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">Eléctricos:</span>
              <span className="font-medium">
                {employees.filter((e) => e.specializations.some((s) => s.includes("eléctrica"))).length}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Estados de Tickets y Equipos */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Estados de Servicios</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm">Abierto:</span>
              <Badge variant="destructive">{tickets.filter((t) => t.status === "abierto").length}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">En Progreso:</span>
              <Badge variant="secondary">{tickets.filter((t) => t.status === "en_progreso").length}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">Esperando Repuestos:</span>
              <Badge variant="outline">{tickets.filter((t) => t.status === "esperando_repuestos").length}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">Cerrado:</span>
              <Badge variant="default">{tickets.filter((t) => t.status === "cerrado").length}</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Estados de Equipos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm">Operativo:</span>
              <Badge variant="default">{allEquipment.filter((e) => e.status === "operativo").length}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">Mantenimiento:</span>
              <Badge variant="secondary">{allEquipment.filter((e) => e.status === "mantenimiento").length}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">En Reparación:</span>
              <Badge variant="outline">{allEquipment.filter((e) => e.status === "en_reparacion").length}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">Fuera de Servicio:</span>
              <Badge variant="destructive">{allEquipment.filter((e) => e.status === "fuera_servicio").length}</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Servicios Recientes */}
      <Card>
        <CardHeader>
          <CardTitle>Servicios Técnicos Recientes</CardTitle>
          <CardDescription>Los últimos 5 tickets de servicio creados en el sistema</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentTickets.map((ticket) => {
              const client = clients.find((c) => c.id === ticket.clientId)
              const equipmentItem = ticket.equipmentId ? allEquipment.find((e) => e.id === ticket.equipmentId) : null

              return (
                <div key={ticket.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 rounded-full bg-blue-500" />
                    <div>
                      <p className="font-medium">
                        #{ticket.id} - {ticket.title}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Cliente: {client?.name} ({client?.company})
                      </p>
                      {equipmentItem && (
                        <p className="text-xs text-muted-foreground">
                          Equipo: {equipmentItem.name} - {equipmentItem.brand}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="text-right space-y-1">
                    <Badge
                      variant={
                        ticket.status === "cerrado"
                          ? "default"
                          : ticket.status === "en_progreso"
                            ? "secondary"
                            : ticket.status === "esperando_repuestos"
                              ? "outline"
                              : "destructive"
                      }
                    >
                      {ticket.status.replace("_", " ")}
                    </Badge>
                    <p className="text-xs text-muted-foreground">{new Date(ticket.createdAt).toLocaleDateString()}</p>
                    {ticket.scheduledDate && (
                      <p className="text-xs text-blue-600 flex items-center">
                        <CalendarDays className="h-3 w-3 mr-1" />
                        {new Date(ticket.scheduledDate).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </div>
              )
            })}
            {recentTickets.length === 0 && (
              <p className="text-center text-muted-foreground py-8">
                No hay tickets recientes. Inicializa la base de datos para ver datos de ejemplo.
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
